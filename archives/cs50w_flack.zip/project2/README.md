# Project 2

Web Programming with Python and JavaScript
main: I have only one page on my website, the main page. It can be either for already authorized user or for a one who needs to get in.

    unauthorized: Unauthorized version of a web page has a form that allows that type in a username. It also checks if this username hasn't been used by someone else.

    authorized:

        channels: After you registered, you now can create a channel (or multiple channels) and open already existing channels. Every channel has a unique name. Once you opened a channel, application remember it. And even if you closed web browser, and later open it again, you'll see a channel that you left on. You can later switch between all the channels.

        messages: When you click on a button of a specific channel, on the right side, you will see all messages in that channel. You can also send a message there. At the bottom, there is a form that has two inputs. a text input and a file input. You can either send a text message or send an image. Or you can send both text and image. After you tapped submit button, this message will appear in the bottom of the chat you are currently on. Each message has its content, author, and time mark.