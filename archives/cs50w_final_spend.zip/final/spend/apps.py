from django.apps import AppConfig


class SpendConfig(AppConfig):
    name = 'spend'