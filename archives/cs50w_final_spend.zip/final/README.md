# Final Project

Web Programming with Python and JavaScript

Spend is my web application where families can record theirs earnings and spendings. Family manager can create account for himself, and when he logged in, he can create account for his family members. They than can log in as regular users and see the same data as a manager. They can see how much they have earned and spend monthly. They can record transactons and then see the whole history of earnings and expencies.

unauthorized: On this page you can see a basic description of the website, and on top there are "Log In" and "Register" buttons. You can create an account or log in into your account using them.

main: After you logged in, you can see overview of how much you have earned and spend this month. You can also see how much money is left in your budget this month. You can choose to see the overview of the last month also. There is a progress bar under overview section, which also shows how much money you have left this month(in percent). And at the bottom of a page, there is a section where you can record a new transaction. Also, on top there is a navigation bar where you can add a family member or create a new category. And of course you can log out.

history: On this page you can see your whole history of transactions since creating your account. There are some basic filters. Like filter by user, or category, or date, or you can only show earnings or expencies.