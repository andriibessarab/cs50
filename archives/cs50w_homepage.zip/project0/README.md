# Project 0

Web Programming with Python and JavaScript

I created a site called "Rubik's Guide". My site is some sort of guide for Rubik's Cube. It describes what is Rubik's Cube, talks about different types of Rubik's Cubes, contain some useful links to instructions how to solve Rubik's Cube, and has a table of all current Rubik's Cubes world records. I have four web pages. Each one has its own topic. I have one stylesheet, the Sass file. 
